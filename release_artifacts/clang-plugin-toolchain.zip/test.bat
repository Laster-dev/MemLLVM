@echo off
cd /d D:/MemLLVM_ci_repro/plugtest
"D:/MemLLVM_ci_repro/minllvm/bin/clang-cl.exe" -c t.c -o t_min.obj /clang:-fpass-plugin=D:/MemLLVM/bin/MemLLVM.dll
echo exit=%ERRORLEVEL%
